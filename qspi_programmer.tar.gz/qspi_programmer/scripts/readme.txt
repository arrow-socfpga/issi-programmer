quartus_cpf -c --device=EPCQ128 -o auto_create_rpd=on -o rpd_little_endian=on -o bitstream_compression=on -m ASx1 ../output_files/programmer.sof ../output_files/payload.pof
