nios2-configure-sof ../output_files/programmer.sof
system-console --script=program_issi.tcl ../output_files/payload.rpd