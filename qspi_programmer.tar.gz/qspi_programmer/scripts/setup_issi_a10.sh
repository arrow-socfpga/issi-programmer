nios2-configure-sof ../output_files/programmer.sof
system-console --script=setup_issi_a10.tcl